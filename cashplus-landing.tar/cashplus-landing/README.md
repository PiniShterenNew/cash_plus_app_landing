# CashPlus — Landing Page

דף נחיתה עבור CashPlus — פלטפורמת ניהול תזרים מזומנים לעסקים קטנים ובינוניים בישראל.

## Tech Stack

- **Next.js 15** (App Router)
- **TypeScript**
- **Tailwind CSS v4**
- **Lucide React** (icons)

## Design System — "Soft Financial Zen"

| Token | Value |
|-------|-------|
| Background | `#FAF8F5` (warm sand) |
| Primary | `#4ECDC4` (mint green) |
| Secondary | `#2D6A4F` (forest green) |
| Text | `#1A1A2E` (ink) |
| Heading font | Varela Round |
| Body font | Rubik |
| Mono font | DM Mono |

## Getting Started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Structure

```
src/
├── app/
│   ├── layout.tsx      # RTL, Hebrew fonts, metadata
│   ├── page.tsx        # Main landing page
│   └── globals.css     # Design tokens, animations
├── components/
│   ├── Navbar.tsx       # Sticky nav with mobile menu
│   ├── Hero.tsx         # Hero + waitlist form
│   ├── SocialProof.tsx  # Social proof bar
│   ├── Features.tsx     # 4 feature cards
│   ├── HowItWorks.tsx   # 3-step flow
│   ├── Pricing.tsx      # 3 pricing tiers
│   ├── FAQ.tsx          # Accordion FAQ
│   ├── FinalCTA.tsx     # Bottom CTA section
│   ├── WaitlistForm.tsx # Reusable email form
│   └── Footer.tsx       # Footer with links
└── lib/
    └── useScrollReveal.ts  # Intersection observer hook
```

## Deployment

```bash
npm run build
# Deploy to Vercel, Netlify, or any static host
```

## TODO

- [ ] Connect waitlist form to Supabase / API
- [ ] Add logo image
- [ ] Set up analytics (Plausible / Vercel Analytics)
- [ ] Add OG image for social sharing
